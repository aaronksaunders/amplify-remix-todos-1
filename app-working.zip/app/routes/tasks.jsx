import { useFetcher, useLoaderData } from "@remix-run/react";
import { Auth, withSSRContext } from "aws-amplify";
import { Heading } from "@aws-amplify/ui-react";
import { logout, requireUserId } from "../session.server";
import { useEffect, useState} from "react";
import { json } from "@remix-run/node";

/**
 * when page loads check server for verified user
 * 
 * @param {*} param0 
 * @returns 
 */
export async function loader({ request }) {
  const response = await requireUserId(request, "/login");
  const { accessToken, idToken } = response || {}

  console.log(withSSRContext(request).DataStore);
  return json({ accessToken, idToken });
}

/**
 * this action function is called when the user logs
 * out of the application. We call logout on server to
 * clear out the session cookies
 */
export const action = async ({ request }) => {
  console.log("in logout action");
  return await logout(request);
};

export default function Tasks() {
  const fetcher = useFetcher();
  const { accessToken, idToken } = useLoaderData();
  const [user,setUser] = useState();

  useEffect(() => {
    Auth.currentUserInfo().then((userInfo) => setUser(userInfo));
  }, [accessToken, idToken]);

  return (
    <div style={{  padding: 16 }}>
      <Heading level={1} textAlign="center">
        Private Page
      </Heading>
      <p>{user && `Logged in with authenticated user ${user?.attributes?.email}`} </p>
      <button
        type="button"
        onClick={async () => {
          // amplify sign out
          await Auth.signOut({ global: true });

          // clear out our session cookie...
          fetcher.submit({}, { method: "post" });
        }}
      >
        Log Out
      </button>
    </div>
  );
}
